import java.util.Scanner;

public class ReverseEncryption {
	public static void main(String[] args) {
		
	Scanner keyboard = new Scanner(System.in);
		
	System.out.println("Enter the 4 didgits you want to decrypt");
	
	int digits = keyboard.nextInt();
	
	System.out.println("You entered " + digits);
	
	}
}
